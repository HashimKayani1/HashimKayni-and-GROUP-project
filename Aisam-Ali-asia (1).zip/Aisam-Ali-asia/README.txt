GlobalExplorer - Aisam Ali - Department: asia

This zip contains ONLY this member assigned pages (pages/asia/)
plus the shared assets/ and design.md needed to preview them locally.

To preview: open pages/asia/hub.html in a browser.

Git workflow (run inside your cloned global-explorer repo, NOT inside this zip):
  git checkout dev
  git pull origin dev
  git checkout -b feature/aisam-ali-asia
  # copy your pages/asia/*.html files into the repo pages/asia/ folder
  git add pages/asia
  git commit -m "feat: add asia pages"
  git push origin feature/aisam-ali-asia
  # then open a Pull Request into dev on GitHub
