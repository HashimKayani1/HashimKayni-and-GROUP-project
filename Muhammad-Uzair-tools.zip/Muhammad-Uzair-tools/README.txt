GlobalExplorer - Muhammad Uzair - Department: tools

This zip contains ONLY this member assigned pages (pages/tools/)
plus the shared assets/ and design.md needed to preview them locally.

To preview: open pages/tools/hub.html in a browser.

Git workflow (run inside your cloned global-explorer repo, NOT inside this zip):
  git checkout dev
  git pull origin dev
  git checkout -b feature/muhammad-uzair-tools
  # copy your pages/tools/*.html files into the repo pages/tools/ folder
  git add pages/tools
  git commit -m "feat: add tools pages"
  git push origin feature/muhammad-uzair-tools
  # then open a Pull Request into dev on GitHub
