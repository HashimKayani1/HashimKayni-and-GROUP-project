GlobalExplorer - Bilal Khizar - Department: europe

This zip contains ONLY this member assigned pages (pages/europe/)
plus the shared assets/ and design.md needed to preview them locally.

To preview: open pages/europe/hub.html in a browser.

Git workflow (run inside your cloned global-explorer repo, NOT inside this zip):
  git checkout dev
  git pull origin dev
  git checkout -b feature/bilal-khizar-europe
  # copy your pages/europe/*.html files into the repo pages/europe/ folder
  git add pages/europe
  git commit -m "feat: add europe pages"
  git push origin feature/bilal-khizar-europe
  # then open a Pull Request into dev on GitHub
