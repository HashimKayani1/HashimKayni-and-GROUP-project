GlobalExplorer - Abdullah Zaheer - Department: north-pk

This zip contains ONLY this member assigned pages (pages/north-pk/)
plus the shared assets/ and design.md needed to preview them locally.

To preview: open pages/north-pk/hub.html in a browser.

Git workflow (run inside your cloned global-explorer repo, NOT inside this zip):
  git checkout dev
  git pull origin dev
  git checkout -b feature/abdullah-zaheer-north-pk
  # copy your pages/north-pk/*.html files into the repo pages/north-pk/ folder
  git add pages/north-pk
  git commit -m "feat: add north-pk pages"
  git push origin feature/abdullah-zaheer-north-pk
  # then open a Pull Request into dev on GitHub
